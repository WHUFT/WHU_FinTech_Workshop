import numpy as np
import pandas as pd
from datetime import datetime

df1 = pd.read_csv('FI_T5.csv')  # 息税前利润
df2 = pd.read_csv('FS_Combas.csv')  # 资产负债表
df3 = pd.read_csv('FS_Comins.csv')  # 净利润
df4 = pd.read_csv('TRD_Mnth.csv')  # 市值，单位是千元

# 计算企业乘数
# 息税前利润数据
df1 = df1[df1['Typrep'] == 'A']  # 筛选合并报表数据
df1['Accper'] = pd.to_datetime(df1['Accper'])
df1 = df1.pivot(
    index='Stkcd',
    columns='Accper',
    values='F050601B'
)
del df1[datetime(2019, 3, 31)]

# 总企业价值
## 总市值
df4 = df4.pivot(
    index='Stkcd',
    columns='Trdmnt',
    values='Msmvttl'
)
df4 = df4[['Sep-18', 'Dec-18', 'Jun-19']]
## 有利息债务 - 货币资金
### 有利息债务
in_debt = df2.iloc[:, 5:].fillna(0).sum(axis=1)
df2['part'] = in_debt - df2['A001101000'].fillna(0)
df2['Accper'] = pd.to_datetime(df2['Accper'])
df5 = df2.pivot(
    index='Stkcd',
    columns='Accper',
    values='part'
)
del df5[datetime(2019, 1, 1)]
del df5[datetime(2019, 3, 31)]
df4.columns = df5.columns

def fill_stock(data1, data2):
    '''
    两个数据的股票代码取并集，并分别补上空行
    
    Parameters
    ----------
    data1: 数据1  (pd.DataFrame)
    data2: 数据2  (pd.DataFrame)

    Returns
    -------
    补齐代码后数据  (tuple of pd.DataFrame)
    '''
    code = list((set(data1.index)) | (set(data2.index)))
    temp = pd.DataFrame([], index=code)
    data1 = pd.concat([temp, data1], axis=1, join='outer')
    data2 = pd.concat([temp, data2], axis=1, join='outer')

    return data1, data2

df4, df5 = fill_stock(df4, df5)
df6 = df4 * 1000 + df5  # 总企业价值

# 企业乘数
df1, df6 = fill_stock(df1, df6)
EM = df1 / df6
EM.to_csv('Enterprise Multiple.csv')


# 计算ROA
df3['Accper'] = pd.to_datetime(df3['Accper'])
df3 = df3.pivot(index='Stkcd', columns='Accper', values='B002000000')
del df3[datetime(2019, 1, 1)]
del df3[datetime(2019, 3, 31)]
## 资产数据
assets = df2.pivot(index='Stkcd', columns='Accper', values='A001000000')
del assets[datetime(2019, 1, 1)]
del assets[datetime(2019, 3, 31)]
df3, assets = fill_stock(df3, assets)
ROA = df3 / assets
ROA.to_csv('ROA.csv')