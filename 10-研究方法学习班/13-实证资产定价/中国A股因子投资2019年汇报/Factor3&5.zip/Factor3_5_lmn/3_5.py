# -*- coding: utf-8 -*-
# =============================================================================
# Factor3: Earning's Yield(Inverse of P/E)
# It is estimated as net profit (net income, CSMAR income statement item “B002000000”) 
# for the fiscal year ending in calendar year t-1 divided by the market equity 
# at the end of December in year t-1.
# ————Basu (1977)
# =============================================================================

# =============================================================================
# Factor5: Sales to Price(S/P)
# It is estimated as operating revenue (CSMAR income statement item “B001101000”) 
# for the fiscal year ending in calendar year t-1 divided by the market equity 
# at the end of December in year t-1.
# ————Barbee, Jr., and Raines (1996)
# =============================================================================
import pandas as pd

df1=pd.read_csv('TRD_Mnth.csv',encoding='gbk') 
df2=pd.read_csv('FS_Comins.csv',encoding='gbk')
df1['Trdmnt']=pd.to_datetime(df1['Trdmnt'])
df1['year']=df1['Trdmnt'].dt.year
df1['month']=df1['Trdmnt'].dt.month
df2=df2[~df2['Typrep'].isin(['B'])]
df2['Accper']=pd.to_datetime(df2['Accper'])
df2=df2[(df2['Accper'] < '2019-7-1') & (df2['Accper'] > '2018-9-1')]
df2['year']=df2['Accper'].dt.year
df2['month']=df2['Accper'].dt.month
df=pd.merge(df1,df2,on=['Stkcd','year','month'])
df['Msmvttl']=df['Msmvttl']*1000
# calculate ep and sp
df['ep']=df['B002000000']/df['Msmvttl']
df['sp']=df['B001101000']/df['Msmvttl']
# store data
data1=pd.pivot_table(df,index=['Stkcd'],columns=['Accper'],values=['ep'])
data2=pd.pivot_table(df,index=['Stkcd'],columns=['Accper'],values=['sp'])
Factor3=data1.iloc[:,[0,0,1,4]]
Factor3.columns=[0,1,2,3]
Factor5=data2.iloc[:,[0,0,1,4]]
Factor5.columns=[0,1,2,3]
Factor3.to_csv('Factor3.csv')
Factor5.to_csv('Factor5.csv')
