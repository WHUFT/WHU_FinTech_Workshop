﻿# -*- coding: utf-8 -*-
"""
Created on Mon Apr  6 20:48:42 2020

@author: shuoshuo
"""
import pandas as pd
import os

os.chdir(r'F:\项目组会\实证资产定价\2019A股因子')
pay = pd.read_csv(r'F:\项目组会\实证资产定价\2019A股因子\偿债能力134807209\FI_T1.csv',header=0)
liq=pay.iloc[:,:4]
lv=pay.iloc[:,[0,1,2,4]]
acc = pd.read_csv(r'F:\项目组会\实证资产定价\2019A股因子\发展能力135019993\FI_T8.csv',header=0)
turn=pd.read_csv(r'F:\项目组会\实证资产定价\2019A股因子\经营能力134845829\FI_T4.csv',header=0)
cash=pd.read_csv(r'F:\项目组会\实证资产定价\2019A股因子\现金流分析134951551\FI_T6.csv',header=0)
profit=pd.read_csv(r'F:\项目组会\实证资产定价\2019A股因子\盈利能力134919894\FI_T5.csv',header=0)
roa=profit.iloc[:,:4]
gm=profit.iloc[:,[0,1,2,4]]
asset=pd.read_csv(r'F:\项目组会\实证资产定价\2019A股因子\资产负债表135213221\FS_Combas.csv',header=0)
ret=pd.read_csv(r'F:\项目组会\实证资产定价\2019A股因子\股票回购\月个股回报率文件231711229\TRD_Mnth.csv',header=0)
issue=ret.iloc[2:,[0,1,6]]
stklist= pd.read_csv(r'F:\项目组会\实证资产定价\数据和说明文档\stkcd.csv',header=0)

def get_f1(data,name,stklist): 
    data=data.dropna()
    try:
        data=data[data['Typrep']=='A']
    except :
        pass
    data=data[~data['Accper'].isin([1/1])]
    data['year']=data['Accper'].str.slice(0,4).astype(float)
    data['mon']=data['Accper'].str.slice(5,-3).astype(float)
    data['month']=data['year']*100+data['mon']
    data=data.iloc[:,[0,3,6]].astype(float)
    data1=data[(data['month']==201809) | (data['month']==201812) | (data['month']==201906)| (data['month']==201909)]
    data1.columns=['stkcd','data','month']
    data1.loc[data1['data']>0,name] = 1
    data1.loc[data1['data']<0,name] = 0
    data2=data1.iloc[:,[0,2,3]]
    return data2

def get_f2(data,name,stklist): 
    #data=cf
   # name ='flv'
    data=data.dropna()
    try:
        data=data[data['Typrep']=='A']
    except :
        pass
    data['year']=data['Accper'].str.slice(0,4).astype(float)
    data['mon']=data['Accper'].str.slice(5,-3).astype(float)
    data['month']=data['year']*100+data['mon']
    data=data.iloc[:,[0,3,6]].astype(float)
    data1=data[(data['month']==201809) | (data['month']==201812) | (data['month']==201906)| (data['month']==201909)]
    data2=data[(data['month']==201709) | (data['month']==201712) | (data['month']==201806)| (data['month']==201809)]
    data2['month']=data2['month']+100
    data2.columns=['Stkcd','data','month']
    data3=pd.merge(data1,data2,on=['Stkcd','month'],how='outer')
    data3.columns=['stkcd','A','month','B'] # B为去年同期
    data3.loc[data3['A']<data3['B'],name] = 1
    data3.loc[data3['A']>=data3['B'],name] = 0
    data4=pd.merge(data3,stklist,on=['stkcd'],how='outer')
    data4=data4[(data4['month']==201809) | (data4['month']==201812) | (data4['month']==201906)| (data4['month']==201909)]
    data4=data4.iloc[:,[0,2,4]]
    return data4

def get_f3(data,name,stklist): 
    #data=issue
   # name ='fissue' 
    data=data.dropna()
    try:
        data=data[data['Typrep']=='A']
    except :
        pass   
    data['year']=data['Trdmnt'].str.slice(0,4).astype(float)
    data['mon']=data['Trdmnt'].str.slice(5,7).astype(float)
    data['month']=data['year']*100+data['mon']
    data=data.iloc[:,[0,2,5]].astype(float)
    data1=data[(data['month']==201809) | (data['month']==201812) | (data['month']==201906)| (data['month']==201909)]
    data2=data[(data['month']==201709) | (data['month']==201712) | (data['month']==201806)| (data['month']==201809)]
    data2['month']=data2['month']+100
    data2.columns=['Stkcd','data','month']
    data3=pd.merge(data1,data2,on=['Stkcd','month'],how='outer')
    data3.columns=['stkcd','A','month','B']
    data3.loc[data3['A']<=data3['B'],name] = 1
    data3.loc[data3['A']>data3['B'],name] = 0
    data4=pd.merge(data3,stklist,on=['stkcd'],how='outer')
    data4=data4[(data4['month']==201809) | (data4['month']==201812) | (data4['month']==201906)| (data4['month']==201909)]
    data4=data4.iloc[:,[0,2,4]]
    return data4
      
cash=cash[cash['Typrep']=='A']
asset=asset[asset['Typrep']=='A']
cash_a=pd.merge(cash,asset,on=['Stkcd','Accper'],how='outer')
cash_a['cf']=cash_a.iloc[:,3]/cash_a.iloc[:,5]
cf=cash_a.iloc[:,[0,1,2,-1]]
fcf=get_f1(cf,'fcf',stklist)
froa=get_f1(roa,'froa',stklist)
facc=get_f1(acc,'facc',stklist)

flv=get_f2(lv,'flv',stklist)
fliq=get_f2(liq,'fliq',stklist)
fturn=get_f2(turn,'fturn',stklist)
fdroa=get_f2(roa,'fdroa',stklist)
fgm=get_f2(gm,'fgm',stklist)
fdcf=get_f2(cf,'fdcf',stklist)

fquiss=get_f3(issue,'fquiss',stklist)

df=fcf
for dt in [froa,facc,flv,fliq,fturn,fdroa,fgm,fdcf,fquiss]:
    df=pd.merge(df,dt,on=['stkcd','month'],how='outer')

df=df.fillna(0)     
df['f']=df['fcf']+df['froa']+df['facc']+df['flv']+df['fliq']+df['fturn']+df['fdroa']+df['fgm']+df['fquiss']
df['fs']=df['fcf']+df['froa']+df['facc']+df['flv']+df['fliq']+df['fturn']+df['fdroa']+df['fgm']+df['fdcf']+df['fquiss']

f_s=df.iloc[:,[0,1,-2]]
fs_s=df.iloc[:,[0,1,-1]]

f_score=f_s.pivot_table(index=['month'],columns=['stkcd'])
f_score.columns=f_score.columns.droplevel(0)
f_score.index=list(range(4))

fs_score=fs_s.pivot_table(index=['month'],columns=['stkcd'])
fs_score.columns=fs_score.columns.droplevel(0)
fs_score.index=list(range(4))

f_score.to_csv('f_score.csv')
fs_score.to_csv('fs_score.csv')