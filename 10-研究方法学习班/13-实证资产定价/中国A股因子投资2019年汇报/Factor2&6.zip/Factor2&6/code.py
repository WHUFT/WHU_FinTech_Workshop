# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

import os
import pandas as pd
import numpy as np

book = pd.read_excel('book.xlsx')

b = pd.DataFrame(index = book.stock.unique(),columns = range(4))
for i in b.index:
    for col,t in [[0,'2018-09-30'],[1,'2018-12-31'],[2,'2019-06-30'],[3,'2019-09-30']]:
        k = book[(book.stock == i)&(book.date == t)].book.tolist()
        if not k:
            b.loc[i][col] = np.nan
        else:
            b.loc[i][col] = k[0]    
del i,t,col,k

value = pd.read_excel('value.xlsx')
v = pd.DataFrame(index = value.stock.unique(),columns = range(4))
for i in v.index:
    for col,t in [[0,'2018-09'],[1,'2018-12'],[2,'2019-06'],[3,'2019-09']]:
        k = value[(value.stock == i)&(value.month == t)].mktvalue.tolist()
        if not k:
            v.loc[i][col] = np.nan
        else:
            v.loc[i][col] = k[0]    
del i,t,col,k

bm = pd.DataFrame(columns = range(4))
bm.iloc[:,0] = b.iloc[:,0]/v.iloc[:,0]
bm.iloc[:,1] = b.iloc[:,1]/v.iloc[:,1]
bm.iloc[:,2] = b.iloc[:,2]/v.iloc[:,2]
bm.iloc[:,3] = b.iloc[:,3]/v.iloc[:,3]

bm.to_excel('bm.xlsx')
#%%
momdata = pd.read_excel('momdata.xlsx')
momdata = momdata[['stock','month','ret']]  # including dividend        

mom = pd.DataFrame(index = momdata.stock.unique(),columns = range(20))
months = [[0,'2018-01'],[1,'2018-02'],[2,'2018-03'],[3,'2018-04'],
          [4,'2018-05'],[5,'2018-06'],[6,'2018-07'],[7,'2018-08'],
          [8,'2018-09'],[9,'2018-10'],[10,'2018-11'],[11,'2018-12'],
          [12,'2019-01'],[13,'2019-02'],[14,'2019-03'],[15,'2019-04'],
          [16,'2019-05'],[17,'2019-06'],[18,'2019-07'],[19,'2019-08'],
          ]
for i in mom.index:
    for col,t in months:
        k = momdata[(momdata.stock == i)&(momdata.month == t)].ret.tolist()
        if not k:
            mom.loc[i][col] = np.nan
        else:
            mom.loc[i][col] = k[0]    

mom = mom.fillna(0)

def calret(col):
    start = col - 11
    end = col -1
    ret = 1
    for i in range(start,end+1):
        ret *= (1 + mom.iloc[:,i])
    return ret-1

m = pd.DataFrame(index = mom.index, columns = range(4))
m.iloc[:,0] = calret(11)
m.iloc[:,1] = calret(14)
m.iloc[:,2] = calret(17)
m.iloc[:,3] = calret(20)

m.to_excel('mom12_2.xlsx')
